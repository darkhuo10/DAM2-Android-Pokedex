
package com.example.pokedex;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.pokedex.adaptador.AdaptadorListaPokemon;
import com.example.pokedex.adaptador.RecyclerItemClickListener;
import com.example.pokedex.conexionAPI.ServicioPokemon;
import com.example.pokedex.entidades.Abilities;
import com.example.pokedex.entidades.Ability;
import com.example.pokedex.entidades.ListaPokemonAPI;
import com.example.pokedex.entidades.Pokemon;
import com.example.pokedex.entidades.Type;
import com.example.pokedex.entidades.Types;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    private Retrofit conexionRetrofit;

    private Context contexto;

    private int offset;

    private RecyclerView listaPokemon;
    private AdaptadorListaPokemon adaptador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contexto = this;

        listaPokemon = findViewById(R.id.listaPokemonRV);
        adaptador = new AdaptadorListaPokemon(contexto);
        listaPokemon.setAdapter(adaptador);

        final GridLayoutManager layoutManager = new GridLayoutManager(contexto, 3);
        listaPokemon.setLayoutManager(layoutManager);

        listaPokemon.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy > 0) {
                    int visibles = layoutManager.getChildCount();
                    int total = layoutManager.getItemCount();
                    int anteriores = layoutManager.findFirstVisibleItemPosition();

                    if ((visibles + anteriores) >= total) {
                        offset += 20;
                        obtenerDatos(offset);
                    }
                }
            }
        });
        conexionRetrofit = new Retrofit.Builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        offset = 0;
        obtenerDatos(0);
    }

    private void obtenerDatos(int offset) {
        ServicioPokemon servicio = conexionRetrofit.create(ServicioPokemon.class);

        Call<ListaPokemonAPI> pokemonAPICall = servicio.hazteConTodos(10, offset);
        pokemonAPICall.enqueue(new Callback<ListaPokemonAPI>() {

            @Override
            public void onResponse(Call<ListaPokemonAPI> call, Response<ListaPokemonAPI> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(contexto, "Conexión exitosa.", Toast.LENGTH_LONG).show();
                    Log.e("aplicacion", "Respuestita" + response.toString());

                    ListaPokemonAPI listaPokemonAPI = response.body();
                    ArrayList<Pokemon> listaPrueba = listaPokemonAPI.getResults();
                    adaptador.agregarListaPokemon(listaPrueba);
                    listaPokemon.addOnItemTouchListener(new RecyclerItemClickListener(contexto, listaPokemon, new RecyclerItemClickListener.OnItemClickListener() {
                        @Override
                        public void onItemClick(View v, int posicion) {
                            Call<Pokemon> pokemonCall = servicio.pokemonPorID(listaPokemonAPI.getResults().get(posicion).getId());
                            String id = String.valueOf(listaPokemonAPI.getResults().get(posicion).getId());
                            String nombre = listaPokemonAPI.getResults().get(posicion).getName();
                            pokemonCall.enqueue(new Callback<Pokemon>() {
                                @Override
                                public void onResponse(Call<Pokemon> call, Response<Pokemon> response) {
                                    if (response.isSuccessful()) {
                                        Intent intent = new Intent(v.getContext(), Detalles.class);
                                        String exp = String.valueOf(response.body().getBase_experience());
                                        String altura = String.valueOf(response.body().getHeight());
                                        String peso = String.valueOf(response.body().getWeight());

                                        List<Ability> abilityList = new ArrayList<>();
                                        StringBuilder sbAbilities = new StringBuilder();
                                        for (Abilities abilities : response.body().getAbilities()) {
                                            abilityList.add(abilities.getAbility());
                                        }
                                        for (Ability a : abilityList) {
                                            sbAbilities.append(a.getName()).append("  ");
                                        }
                                        String abilities = sbAbilities.toString();

                                        List<Type> typesList = new ArrayList<>();
                                        StringBuilder sbTypes = new StringBuilder();
                                        for (Types types : response.body().getTypes()) {
                                            typesList.add(types.getType());
                                        }
                                        for (Type t : typesList) {
                                            sbTypes.append(t.getName()).append("  ");
                                        }
                                        String types = sbTypes.toString();

                                        ArrayList<String> pokemon = new ArrayList<>();
                                        pokemon.add(id);
                                        pokemon.add(nombre);
                                        pokemon.add(exp);
                                        pokemon.add(abilities);
                                        pokemon.add(types);
                                        pokemon.add(peso);
                                        pokemon.add(altura);


                                        intent.putStringArrayListExtra("pokemon", pokemon);
                                        v.getContext().startActivity(intent);
                                    }
                                }

                                @Override
                                public void onFailure(Call<Pokemon> call, Throwable t) {
                                    Log.e("aplicacion", "fallito" + t.getMessage());
                                }
                            });
                        }

                        @Override
                        public void onLongItemClick(View v, int posicion) {
                        }
                    }));



                } else {
                    Toast.makeText(contexto, "Conexion fallida: " + response.toString(), Toast.LENGTH_LONG).show();
                    Log.e("aplicación", "Respuestita: " + response.toString());
                }

            }

            @Override
            public void onFailure(Call<ListaPokemonAPI> call, Throwable t) {
                Log.e("aplicacion", "fallito" + t.getMessage());

            }
        });

    }

}