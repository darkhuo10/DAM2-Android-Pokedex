package com.example.pokedex.conexionAPI;

import com.example.pokedex.entidades.ListaPokemonAPI;
import com.example.pokedex.entidades.Pokemon;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ServicioPokemon {

    @GET("pokemon")
    Call<ListaPokemonAPI> hazteConTodos (@Query("Limit") int Limit, @Query("offset") int offset);


    @GET("pokemon/{id}")
    Call<Pokemon> pokemonPorID(@Path("id") int id);


}
