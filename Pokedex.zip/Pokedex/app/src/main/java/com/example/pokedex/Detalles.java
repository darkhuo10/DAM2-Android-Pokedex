package com.example.pokedex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Detalles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);
        Intent intent = getIntent();
        ArrayList<String> lista = intent.getStringArrayListExtra("pokemon");

        int id = Integer.parseInt(lista.get(0));
        String nombre = lista.get(1);
        String exp = lista.get(2);
        String abilities = lista.get(3);
        String types = lista.get(4);
        String peso = lista.get(5);
        String altura = lista.get(6);

        ImageView imagen = findViewById(R.id.detallesSprite);

        TextView tvNombre = findViewById(R.id.detallesNombre);
        TextView tvExp = findViewById(R.id.detallesExp);
        TextView tvAltura = findViewById(R.id.detallesAltura);
        TextView tvPeso = findViewById(R.id.detallesPeso);
        TextView tvTipos = findViewById(R.id.detallesTipos);
        TextView tvHabilidades = findViewById(R.id.detallesHabilidades);


        Picasso.with(imagen.getContext())
                .load("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/" + id + ".png")
                .resize(500, 0)
                .into(imagen);



        tvNombre.setText(nombre);
        tvExp.setText(exp);
        tvAltura.setText(altura);
        tvPeso.setText(peso);
        tvTipos.setText(types);
        tvHabilidades.setText(abilities);

    }

}